import os
import time
import uuid
import threading
from datetime import datetime
from flask import Flask, request, jsonify, send_file, render_template
from flask_cors import CORS
import openpyxl
import csv
import requests
from dotenv import load_dotenv
from io import StringIO
from google.oauth2 import service_account
from googleapiclient.discovery import build

# Load configuration
load_dotenv()
ACCESS_TOKEN = os.getenv("WHATSAPP_TOKEN", "").strip()
PHONE_NUMBER_ID = os.getenv("PHONE_NUMBER_ID", "").strip()
TEMPLATE_NAME = os.getenv("TEMPLATE_NAME", "").strip()
TEMPLATE_LANGUAGE = os.getenv("TEMPLATE_LANGUAGE", "id").strip()
API_KEY = os.getenv("API_KEY", "").strip()
GOOGLE_SA_CREDENTIALS = os.getenv("GOOGLE_SA_CREDENTIALS", "service_account.json")
GOOGLE_SHEET_ID = os.getenv("GOOGLE_SHEET_ID", "").strip()

if not ACCESS_TOKEN or not PHONE_NUMBER_ID or not API_KEY:
    raise RuntimeError("WHATSAPP_TOKEN, PHONE_NUMBER_ID, dan API_KEY harus diset di .env")

API_BASE = f"https://graph.facebook.com/v17.0/{PHONE_NUMBER_ID}/messages"

app = Flask(__name__, template_folder="templates")
CORS(app)

SESSIONS = {}

def now_iso():
    return datetime.utcnow().isoformat() + "Z"

def require_api_key(func):
    def wrapper(*args, **kwargs):
        key = request.headers.get("X-API-KEY", "")
        if key != API_KEY:
            return jsonify({"error": "Unauthorized"}), 401
        return func(*args, **kwargs)
    wrapper.__name__ = func.__name__
    return wrapper

def send_text(to_number: str, message_text: str):
    headers = {
        "Authorization": f"Bearer {ACCESS_TOKEN}",
        "Content-Type": "application/json"
    }
    payload = {
        "messaging_product": "whatsapp",
        "to": to_number,
        "type": "text",
        "text": {"preview_url": False, "body": message_text}
    }
    return requests.post(API_BASE, headers=headers, json=payload, timeout=30)

def send_template(to_number: str, message_text: str):
    headers = {
        "Authorization": f"Bearer {ACCESS_TOKEN}",
        "Content-Type": "application/json"
    }
    payload = {
        "messaging_product": "whatsapp",
        "to": to_number,
        "type": "template",
        "template": {
            "name": TEMPLATE_NAME,
            "language": {"code": TEMPLATE_LANGUAGE},
            "components": [
                {
                    "type": "body",
                    "parameters": [
                        {"type": "text", "text": message_text}
                    ]
                }
            ]
        }
    }
    return requests.post(API_BASE, headers=headers, json=payload, timeout=30)

def push_to_google_sheets(session_id):
    session = SESSIONS.get(session_id)
    if not session or not os.getenv("GOOGLE_SHEET_ID"):
        return
    try:
        creds = service_account.Credentials.from_service_account_file(
            os.getenv("GOOGLE_SA_CREDENTIALS"),
            scopes=["https://www.googleapis.com/auth/spreadsheets"]
        )
        sheets = build("sheets", "v4", credentials=creds)
        values = []
        for e in session["entries"]:
            values.append([
                session_id,
                e["number"],
                e["message"],
                e["status"],
                str(e["attempts"]),
                e["last_attempt"] or "",
                session.get("created_at", "")
            ])
        body = {"values": values}
        sheets.spreadsheets.values.append(
            spreadsheetId=os.getenv("GOOGLE_SHEET_ID"),
            range="Sheet1!A:G",
            valueInputOption="RAW",
            insertDataOption="INSERT_ROWS",
            body=body
        ).execute()
    except Exception as ex:
        print("GSheet sync failed:", ex)

def worker(session_id: str):
    session = SESSIONS.get(session_id)
    if not session:
        return
    entries = session["entries"]
    delay = session["config"].get("delay", 1)
    max_retry = session["config"].get("max_retry", 3)
    for entry in entries:
        if session.get("stopped"):
            break
        if entry["status"] == "done":
            continue
        number = entry["number"]
        text = entry["message"]
        entry["attempts"] += 1
        entry["last_attempt"] = now_iso()
        entry["status"] = "sending"
        session["log"].append({
            "timestamp": now_iso(),
            "number": number,
            "action": f"attempt_{entry['attempts']}"
        })
        success = False
        resp = send_text(number, text)
        code = resp.status_code
        try:
            body = resp.json()
        except:
            body = {}
        if 200 <= code < 300:
            success = True
            entry["status"] = "done"
            session["log"].append({
                "timestamp": now_iso(),
                "number": number,
                "action": "sent_session"
            })
        else:
            if TEMPLATE_NAME and entry["attempts"] == 1:
                resp2 = send_template(number, text)
                code2 = resp2.status_code
                try:
                    body2 = resp2.json()
                except:
                    body2 = {}
                if 200 <= code2 < 300:
                    success = True
                    entry["status"] = "done"
                    session["log"].append({
                        "timestamp": now_iso(),
                        "number": number,
                        "action": "sent_template"
                    })
                else:
                    session["log"].append({
                        "timestamp": now_iso(),
                        "number": number,
                        "action": f"template_failed_{code2}"
                    })
            else:
                session["log"].append({
                    "timestamp": now_iso(),
                    "number": number,
                    "action": f"failed_session_{code}"
                })
        if not success:
            if entry["attempts"] >= max_retry:
                entry["status"] = "failed"
                session["log"].append({
                    "timestamp": now_iso(),
                    "number": number,
                    "action": "permanently_failed"
                })
            else:
                entry["status"] = "pending"
        session["updated_at"] = now_iso()
        time.sleep(delay)
    session["running"] = False
    push_to_google_sheets(session_id)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/start", methods=["POST"])
@require_api_key
def start():
    delay = float(request.form.get("delay", 1))
    max_retry = int(request.form.get("max_retry", 3))
    if "file" not in request.files:
        return jsonify({"error": "file required"}), 400
    f = request.files["file"]
    filename = f.filename.lower()
    entries = []
    try:
        if filename.endswith((".xlsx", ".xls")):
            wb = openpyxl.load_workbook(f, read_only=True)
            sheet = wb.active
            for row in sheet.iter_rows(min_row=2, values_only=True):
                if not row or not row[0]:
                    continue
                number = str(row[0]).strip()
                message = str(row[1]).strip() if len(row) > 1 and row[1] else ""
                if number and message:
                    entries.append({
                        "number": number,
                        "message": message,
                        "status": "pending",
                        "attempts": 0,
                        "last_attempt": None
                    })
        elif filename.endswith(".csv"):
            content = f.read().decode("utf-8")
            reader = csv.reader(StringIO(content))
            next(reader, None)
            for row in reader:
                if not row or not row[0]:
                    continue
                number = row[0].strip()
                message = row[1].strip() if len(row) > 1 else ""
                if number and message:
                    entries.append({
                        "number": number,
                        "message": message,
                        "status": "pending",
                        "attempts": 0,
                        "last_attempt": None
                    })
        else:
            return jsonify({"error": "unsupported file type"}), 400
    except Exception as e:
        return jsonify({"error": f"parsing failed: {e}"}), 500
    session_id = str(uuid.uuid4())
    SESSIONS[session_id] = {
        "entries": entries,
        "config": {"delay": delay, "max_retry": max_retry},
        "log": [],
        "running": True,
        "stopped": False,
        "created_at": now_iso(),
        "updated_at": now_iso()
    }
    threading.Thread(target=worker, args=(session_id,), daemon=True).start()
    return jsonify({"session_id": session_id})

@app.route("/status/<session_id>", methods=["GET"])
@require_api_key
def status(session_id):
    session = SESSIONS.get(session_id)
    if not session:
        return jsonify({"error": "not found"}), 404
    return jsonify({
        "entries": session["entries"],
        "log": session["log"],
        "running": session["running"],
        "stopped": session["stopped"],
        "config": session["config"],
        "created_at": session["created_at"],
        "updated_at": session["updated_at"]
    })

@app.route("/stop/<session_id>", methods=["POST"])
@require_api_key
def stop(session_id):
    session = SESSIONS.get(session_id)
    if not session:
        return jsonify({"error": "not found"}), 404
    session["stopped"] = True
    session["running"] = False
    return jsonify({"ok": True})

@app.route("/export/<session_id>", methods=["GET"])
@require_api_key
def export(session_id):
    session = SESSIONS.get(session_id)
    if not session:
        return jsonify({"error": "not found"}), 404
    output = StringIO()
    writer = csv.writer(output)
    writer.writerow(["number", "message", "status", "attempts", "last_attempt"])
    for e in session["entries"]:
        writer.writerow([e["number"], e["message"], e["status"], e["attempts"], e["last_attempt"]])
    output.seek(0)
    return send_file(StringIO(output.read()), mimetype="text/csv", download_name=f"blast_export_{session_id}.csv")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
