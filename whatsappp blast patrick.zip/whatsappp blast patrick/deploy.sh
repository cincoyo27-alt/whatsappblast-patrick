#!/bin/bash
# Build and run local docker container
docker build -t whatsapp-blast .
docker run -d --name whatsapp-blast -p 5000:5000 --env-file .env whatsapp-blast
echo "Running at http://localhost:5000"
