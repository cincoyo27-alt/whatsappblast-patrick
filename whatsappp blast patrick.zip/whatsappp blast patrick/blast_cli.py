import argparse
import requests
import os
import json

API_URL = "http://localhost:5000"
API_KEY = os.getenv("API_KEY", "supersecretapikey123")

def start_blast(file_path, delay, max_retry):
    with open(file_path, "rb") as f:
        files = {"file": (os.path.basename(file_path), f)}
        data = {"delay": delay, "max_retry": max_retry}
        headers = {"X-API-KEY": API_KEY}
        resp = requests.post(f"{API_URL}/start", files=files, data=data, headers=headers)
        return resp.json()

def get_status(session_id):
    headers = {"X-API-KEY": API_KEY}
    resp = requests.get(f"{API_URL}/status/{session_id}", headers=headers)
    return resp.json()

def export_log(session_id, out_file):
    headers = {"X-API-KEY": API_KEY}
    resp = requests.get(f"{API_URL}/export/{session_id}", headers=headers)
    if resp.status_code == 200:
        with open(out_file, "wb") as f:
            f.write(resp.content)
        print(f"Exported to {out_file}")
    else:
        print("Failed to export:", resp.text)

def main():
    parser = argparse.ArgumentParser(description="WhatsApp Blast CLI")
    sub = parser.add_subparsers(dest="cmd")
    p1 = sub.add_parser("start")
    p1.add_argument("file", help="CSV/XLSX file with nomor,pesan")
    p1.add_argument("--delay", type=float, default=1.0)
    p1.add_argument("--max-retry", type=int, default=3)
    p2 = sub.add_parser("status")
    p2.add_argument("session_id")
    p3 = sub.add_parser("export")
    p3.add_argument("session_id")
    p3.add_argument("out", help="output csv path")
    args = parser.parse_args()
    if args.cmd == "start":
        result = start_blast(args.file, args.delay, args.max_retry)
        print(json.dumps(result, indent=2))
    elif args.cmd == "status":
        result = get_status(args.session_id)
        print(json.dumps(result, indent=2))
    elif args.cmd == "export":
        export_log(args.session_id, args.out)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
